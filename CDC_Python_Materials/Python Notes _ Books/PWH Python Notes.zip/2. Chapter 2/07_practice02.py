number = int(input("Enter the number: "))
print("Remainder when the number is divided by 2 is:", number%2)