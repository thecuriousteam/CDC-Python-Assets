a = 346
b = 80

print("a is greater than b is:", a>b)