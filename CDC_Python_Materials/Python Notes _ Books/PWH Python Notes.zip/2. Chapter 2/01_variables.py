a = 34
c = 56.23
e = "A Duck"
print(a)
print(e)
print(c)
d = None
print(d)
i5k5 = 34