a = "This is a"
b = 34
c = None
d = False

print(a)
print(b)
print(c)
print(d)

print(type(a))
print(type(b))
print(type(c))
print(type(d))

