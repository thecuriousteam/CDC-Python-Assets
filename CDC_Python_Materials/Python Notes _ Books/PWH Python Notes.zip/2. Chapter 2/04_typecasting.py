a = 56
b = "56y"
c = int(b)

print(a)
print(b)
print(c)

print(a==b)
print(a==c)
print(b==c)

print(type(a))
print(type(b))
print(type(c))