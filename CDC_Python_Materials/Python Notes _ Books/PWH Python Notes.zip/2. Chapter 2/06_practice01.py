a = int(input("Enter the first Number: "))
b = int(input("Enter the second Number: "))

print("The sum of these two numbers is:", a+b)