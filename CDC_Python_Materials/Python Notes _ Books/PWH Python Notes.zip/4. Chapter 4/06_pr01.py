f1 = input("Enter fruit 1: ")
f2 = input("Enter fruit 2: ")
f3 = input("Enter fruit 3: ")
f4 = input("Enter fruit 4: ")

fruitList = [f1, f2, f3, f4]
print(fruitList)