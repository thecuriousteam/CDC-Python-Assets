myListOfNumbers = [1, 8, 7, 2, 21, 15]
print(myListOfNumbers)
# myListOfNumbers.sort() # Sorts the original list
# myListOfNumbers.reverse() # Reverses the original list
# myListOfNumbers.append(9) # Add 9 at the end of the original list
# myListOfNumbers.insert(2, 9) # Inserts 9 at index 2
# myListOfNumbers.pop() # Removes an item from the end of the list   
# myListOfNumbers.pop(2) # Removes an item from the given index from the list   
myListOfNumbers.remove(21) # Removes the first occurence of a given item from the list   
print(myListOfNumbers)
