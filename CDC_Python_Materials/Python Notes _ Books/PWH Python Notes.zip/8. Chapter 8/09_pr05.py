def printPattern(n):
    for i in range(n): 
        print("*"*(n-i)) 

printPattern(3) 
