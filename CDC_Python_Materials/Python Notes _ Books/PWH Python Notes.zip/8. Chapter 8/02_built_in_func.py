print("I am a build in function called print")

for i in range(3):
    print(i)