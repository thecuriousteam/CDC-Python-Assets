print("Harry and Raj", end="")
print("and Simran", end="")