name = input("Enter your name: ")
print("Good afternoon " + name)