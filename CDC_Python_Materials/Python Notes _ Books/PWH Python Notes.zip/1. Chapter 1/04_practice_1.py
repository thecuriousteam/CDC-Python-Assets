# print("Twinkle, twinkle, little star")
# print("How I wonder what you are")
# print("Up above the world so high")
# print("Like a diamond in the sky")
# print("Twinkle, twinkle little star")
# print("How I wonder what you are")
# print("When the blazing sun is gone")
# print("When he nothing shines upon")
# print("Then you show your little light")
# print("Twinkle, twinkle, all the night")
# print("Twinkle, twinkle, little star")
# print("How I wonder what you are")

print('''Twinkle, twinkle, little star
How I wonder what you are
Up above the world so high
Like a diamond in the sky
Twinkle, twinkle little star
How I wonder what you are
When the blazing sun is gone
When he nothing shines upon
Then you show your little light
Twinkle, twinkle, all the night
Twinkle, twinkle, little star
How I wonder what you are''')
