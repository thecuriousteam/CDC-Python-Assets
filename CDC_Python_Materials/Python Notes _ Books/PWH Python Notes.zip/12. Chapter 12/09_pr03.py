num = int(input("Enter a number: "))

multiplication = [i*num for i in range(1, 11)]
print(multiplication)