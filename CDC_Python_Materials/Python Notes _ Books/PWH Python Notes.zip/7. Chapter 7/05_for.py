for i in range(10, 34, 3):
    print(i)