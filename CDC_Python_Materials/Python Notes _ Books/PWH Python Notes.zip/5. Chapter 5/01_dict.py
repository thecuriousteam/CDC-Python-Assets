oxford = {
    "gift": "Something willingly given to someone to appreciate",
    "this": "A keyword in c++",
    "Youtube": "A video sharing platform",
    "instagram": "a picture sharing platform",
    "mylist": [1, 3, 45]
}


# print(oxford)
print(oxford['this'])
# print(oxford['notpresent'])
print(oxford.get('notpresent'))