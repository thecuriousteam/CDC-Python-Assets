a = 435
b = 64

print(a>5)
print(b>=164)