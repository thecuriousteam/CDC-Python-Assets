name = 'Shubhi'
names = ['Harry', 'Shubham', 'Meena']
if(name in names):
    print('Name is present')

else:
    print("Name is not present")