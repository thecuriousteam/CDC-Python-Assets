text = input("Enter your text: ")
if 'harry' in text.lower():
    print("Yes harry is present")
else:
    print("No harry is not present")